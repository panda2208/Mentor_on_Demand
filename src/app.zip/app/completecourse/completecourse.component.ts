import { Component } from '@angular/core';

@Component({
  selector: 'app-signin',
  templateUrl: './completecourse.component.html',
  styleUrls: ['./completecourse.component.css']
})
export class CompletecourseComponent   {
}