import { Component } from '@angular/core';

@Component({
  selector: 'app-signin',
  templateUrl: './currentcourse.component.html',
  styleUrls: ['./currentcourse.component.css']
})
export class CurrentcourseComponent   {
}