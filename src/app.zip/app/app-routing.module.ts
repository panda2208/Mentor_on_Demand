import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { CurrentcourseComponent } from './currentcourse/currentcourse.component';
import { CompletecourseComponent } from './completecourse/completecourse.component';

const routes: Routes = [
  {
    path: 'signin', component:SigninComponent},
    {
      path: 'signup', component:SignupComponent},
      {
        path: 'user', component:UserComponent},
        {
          path: 'home', component:HomeComponent},
          {
            path: 'currentcourse', component:CurrentcourseComponent},
            {
              path: 'completecourse', component:CompletecourseComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
