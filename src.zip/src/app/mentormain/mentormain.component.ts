import { Component } from '@angular/core';

@Component({
  selector: 'app-mentormain',
  templateUrl: './mentormain.component.html',
  styleUrls: ['./mentormain.component.css']
})
export class MentormainComponent   {
}