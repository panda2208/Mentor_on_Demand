import { Component } from '@angular/core';

@Component({
  selector: 'app-mentorcurrent',
  templateUrl: './mentorcurrent.component.html',
  styleUrls: ['./mentorcurrent.component.css']
})
export class MentorcurrentComponent   {
}