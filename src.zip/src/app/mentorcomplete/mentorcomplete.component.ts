import { Component } from '@angular/core';

@Component({
  selector: 'app-mentorcomplete',
  templateUrl: './mentorcomplete.component.html',
  styleUrls: ['./mentorcomplete.component.css']
})
export class MentorcompleteComponent   {
}