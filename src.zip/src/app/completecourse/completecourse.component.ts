import { Component } from '@angular/core';

@Component({
  selector: 'app-completecourse',
  templateUrl: './completecourse.component.html',
  styleUrls: ['./completecourse.component.css']
})
export class CompletecourseComponent   {
}