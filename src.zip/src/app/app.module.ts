import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { CurrentcourseComponent } from './currentcourse/currentcourse.component';
import { CompletecourseComponent } from './completecourse/completecourse.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentdetailComponent } from './paymentdetail/paymentdetail.component';
import { MentorComponent }  from './mentor/mentor.component';
import { MentormainComponent }  from './mentormain/mentormain.component';
import { MentorcurrentComponent }  from'./mentorcurrent/mentorcurrent.component';
import { MentorcompleteComponent }  from'./mentorcomplete/mentorcomplete.component';
import { MentorpaymentComponent }  from'./mentorpayment/mentorpayment.component';
import { AdminComponent }  from'./admin/admin.component';
import { AdminaddComponent }  from'./adminadd/adminadd.component';
import { AdminmentorComponent }  from'./adminmentor/adminmentor.component';
import { AdminuserComponent }  from'./adminuser/adminuser.component';
@NgModule({
  declarations: [
    AppComponent,
    SigninComponent,
    SignupComponent,
    UserComponent,
    HomeComponent,
    CurrentcourseComponent,
    CompletecourseComponent,
    PaymentComponent,
    PaymentdetailComponent,
    MentorComponent,
    MentormainComponent,
    MentorcurrentComponent,
    MentorcompleteComponent,
    MentorpaymentComponent,
    AdminComponent,
    AdminaddComponent,
    AdminmentorComponent,
    AdminuserComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
